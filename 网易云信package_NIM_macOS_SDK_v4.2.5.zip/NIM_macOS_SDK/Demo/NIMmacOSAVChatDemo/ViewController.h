//
//  ViewController.h
//  NIMmacOSAVChatDemo
//
//  Created by fenric on 2017/8/24.
//  Copyright © 2017年 fenric. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

