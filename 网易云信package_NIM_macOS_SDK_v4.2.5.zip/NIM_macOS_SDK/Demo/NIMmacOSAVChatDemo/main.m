//
//  main.m
//  NIMmacOSAVChatDemo
//
//  Created by fenric on 2017/8/24.
//  Copyright © 2017年 fenric. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
