#import "GPUImageTwoInputFilter.h"

/** Applies a color burn blend of two images
 */
@interface GPUImageColorBurnBlendFilter : GPUImageTwoInputFilter
{
}

@end
