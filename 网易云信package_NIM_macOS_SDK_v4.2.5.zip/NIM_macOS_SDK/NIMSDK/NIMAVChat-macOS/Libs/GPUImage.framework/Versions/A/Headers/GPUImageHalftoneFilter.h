#import "GPUImagePixellateFilter.h"

@interface GPUImageHalftoneFilter : GPUImagePixellateFilter

@end
