//
//  NIMTipObject.h
//  NIMLib
//
//  Created by Netease.
//  Copyright © 2015年 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NIMMessageObjectProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface NIMTipObject : NSObject<NIMMessageObject>

@end

NS_ASSUME_NONNULL_END